import requests
from bs4 import BeautifulSoup





def getdeatelseitem(urldef):
    

    harder={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",

            "Accept-Language":"en" }
           
      

    r=requests.get(urldef,headers=harder)

    su=BeautifulSoup(r.text,"html.parser")

    name=su.select_one(selector="#productTitle").getText()

    price=su.select_one(selector=".a-dynamic-image")

    
    return name, price['src']










           
 









