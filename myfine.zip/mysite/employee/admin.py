from django.contrib import admin
from .models import about
# Register your models here.

admin.site.register(about)