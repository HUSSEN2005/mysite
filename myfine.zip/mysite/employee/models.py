from django.db import models




# Create your models here.


class about(models.Model):
    name=models.CharField(max_length=800)
    image=models.CharField(max_length=800)
    price=models.CharField(max_length=800)
    

    

   
   
