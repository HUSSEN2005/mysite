from django import forms



class My_formhussen(forms.Form):

    username=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"style":"color:red","name":"alimajhed"}))
    emaill=forms.CharField(max_length=100,label="myrmaill")
