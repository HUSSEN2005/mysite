from  django.http import HttpResponse
from  django.shortcuts import render
from .models import about
from .utils import getdeatelseitem
import json
from .formes import My_formhussen






url="https://www.amazon.com/All-new-Essentials-including-Graphite-Amazon/dp/B07RQNBBL8/ref=sr_1_1?keywords=Kindle+E-readers&pd_rd_r=9a020481-12f8-4340-8573-565d511b88ac&pd_rd_w=TdIZx&pd_rd_wg=pDA9K&pf_rd_p=b9deb6fa-f7f0-4f9b-bfa0-824f28f79589&pf_rd_r=9FP91CM7KAC0Q1ZZRX0R&qid=1688161838&sr=8-1"
def home(Requst):
    
 
 datebb1={
    'date':about.objects.all(),
    
} 
 name,image=getdeatelseitem(urldef=Requst.GET['urlitem'])
 dateisert=about(name=name,image=image,price="22")
 dateisert.save()
     
     
      
        


 return render(Requst,'index.html',context=datebb1)




    
    
daye=about.objects.all()

 
def homeview(req):
  dea={"myform":My_formhussen}
  return render(req,'appbar.html')