from  django.http import HttpResponse

from  django.shortcuts import render

from io import BytesIO







def home(Requst):
    return render(Requst,'index.html')


