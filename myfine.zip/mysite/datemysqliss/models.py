from django.db import models

class MyModel(models.Model):
    name = models.CharField(max_length=800)
    image = models.CharField(max_length=200)
    pri=models.CharField(max_length=111,blank=False)
    moqitems=models.CharField(max_length=100)


    # Add other fields as required
