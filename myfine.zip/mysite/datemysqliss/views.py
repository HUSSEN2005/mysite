from  django.http import HttpResponse
from  django.shortcuts import render
from .models import MyModel
from .uitls import getdateitemalibab
import json





ulr="https://www.alibaba.com/product-detail/CKMINE-220V-Single-Phase-Dc-3_60748437339.html?spm=a2700.7699653.0.0.7bc23e5fVg19yk"



abotdate=MyModel.objects.all()


datebb={
    'daten':abotdate,
    
} 
def ruslut(Requs):
   
   return HttpResponse("yes isertes")

def home(Requst):
    
 
 name1,image1,price1=getdateitemalibab(url=Requst.GET['name'])

 dateinserted=MyModel(name=name1,image=image1,pri=price1,moqitems="12")
        
        
        
        
        
     
 dateinserted.save()
    
 return HttpResponse("yes")
     
     
      
        







    
    
   
